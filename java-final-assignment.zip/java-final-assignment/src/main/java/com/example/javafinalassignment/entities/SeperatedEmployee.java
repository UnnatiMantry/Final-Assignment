package com.example.javafinalassignment.entities;

public class SeperatedEmployee {

    private String empCode;
    private String dateofSeparation;
    private String dateofResignation;
    public String getEmpCode() {
        return empCode;
    }
    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }
    public String getDateofSeparation() {
        return dateofSeparation;
    }
    public void setDateofSeparation(String dateofSeparation) {
        this.dateofSeparation = dateofSeparation;
    }
    public String getDateofResignation() {
        return dateofResignation;
    }
    public void setDateofResignation(String dateofResignation) {
        this.dateofResignation = dateofResignation;
    }



}
