package com.example.javafinalassignment.EmployUtility;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.example.javafinalassignment.EmployeeDAO.EmployeeDB;
import com.example.javafinalassignment.entities.Employee;
import com.example.javafinalassignment.entities.SeperatedEmployee;
import org.springframework.beans.factory.annotation.Autowired;

public class EmployeeUtility {

    @Autowired
    private EmployeeDB employeeDB;
    public String genEmployeeCode(Employee e)
    {
        String employeeCode="";
        if(e.getEmpType().equals("FTE"))
        {
            employeeCode="HOP-"+e.getYearOfJoining()+"-FTE-"+employeeDB.employeeCount();
        }
        else if(e.getEmpType().equals("STE"))
        {
            employeeCode="HOP-STE-"+employeeDB.employeeCount();
        }
        else if(e.getEmpType().equals("INTERNS"))
        {
            employeeCode="HOP-INT-"+employeeDB.employeeCount();
        }

        return employeeCode;
    }
    public String genEmployeeEmail(Employee emp)
    {
        String email="";
        int employeeCount=0;
        for(Employee e : employeeDB.list)
        {
            if(e.getFirstName().equals(emp.getFirstName()) && e.getLastName().equals(emp.getLastName()))
            {
                employeeCount++;
            }
        }
        if(employeeCount==0)
        {
            email=emp.getFirstName()+"."+emp.getLastName()+"@hoppipolla.com";
        }
        else
        {
            employeeCount++;
            email=emp.getFirstName()+"."+emp.getLastName()+employeeCount+"@hoppipolla.com";
        }

        return email;
    }

    public String employeeRegination(Employee e)
    {
        long ltime=0;
        SeperatedEmployee semp= new SeperatedEmployee();
        Date rdate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        semp.setEmpCode(e.getEmpCode());
        semp.setDateofResignation(formatter.format(rdate));
        if(e.getEmpType().equals("FTE"))
        {
            ltime=rdate.getTime()+45*24*60*60*1000;
        }
        else if(e.getEmpType().equals("STE"))
        {
            ltime=rdate.getTime()+30*24*60*60*1000;
        }
        else if(e.getEmpType().equals("INTERNS"))
        {
            ltime=rdate.getTime()+30*24*60*60*1000;
        }
        Date sdate = new Date(ltime);
        semp.setDateofSeparation(formatter.format(sdate));
        return e.getEmpCode()+",Your Seperation request is saved date of seperation is"+semp.getDateofSeparation();
    }

}

