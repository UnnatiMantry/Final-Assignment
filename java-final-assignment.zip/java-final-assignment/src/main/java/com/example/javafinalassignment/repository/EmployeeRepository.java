package com.example.javafinalassignment.repository;

public class EmployeeRepository {
}
