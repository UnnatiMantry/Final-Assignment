package com.example.javafinalassignment.entities;

public class Employee {

    private String firstName;

    private String lastName;

    private String address;

    private String city;

    private String pin;

    private String state;

    private String contactNumber;

    private String secContactNumber;

    private int yearOfJoining;

    private String empType;

    private String empId;

    private String empCode;

    private String email;

    private boolean isActive;

    private String joiningDate;


    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }

    public String getFirstName() {

        return firstName;

    }

    public void setFirstName(String firstName) {

        this.firstName = firstName;

    }

    public String getLastName() {

        return lastName;

    }

    public void setLastName(String lastName) {

        this.lastName = lastName;

    }

    public String getAddress() {

        return address;

    }

    public void setAddress(String address) {

        this.address = address;

    }

    public String getCity() {

        return city;

    }

    public void setCity(String city) {

        this.city = city;

    }

    public String getPin() {

        return pin;

    }

    public void setPin(String pin) {

        this.pin = pin;

    }

    public String getState() {

        return state;

    }

    public void setState(String state) {

        this.state = state;

    }

    public String getContactNumber() {

        return contactNumber;

    }

    public void setContactNumber(String contactNumber) {

        this.contactNumber = contactNumber;

    }

    public String getSecContactNumber() {

        return secContactNumber;

    }

    public void setSecContactNumber(String secContactNumber) {

        this.secContactNumber = secContactNumber;

    }

    public int getYearOfJoining() {

        return yearOfJoining;

    }

    public void setYearOfJoining(int yearOfJoining) {

        this.yearOfJoining = yearOfJoining;

    }

    public String getEmpType() {

        return empType;

    }

    public void setEmpType(String empType) {

        this.empType = empType;

    }

    public String getEmpId() {

        return empId;

    }

    public void setEmpId(String empId) {

        this.empId = empId;

    }

    public String getEmpCode() {

        return empCode;

    }

    public void setEmpCode(String empCode) {

        this.empCode = empCode;

    }

    public String getEmail() {

        return email;

    }

    public void setEmail(String email) {

        this.email = email;

    }

    public Employee(String firstName, String lastName, String address, String city, String pin, String state, String contactNumber, String secContactNumber, int yearOfJoining, String empId) {

        this.firstName = firstName;

        this.lastName = lastName;

        this.address = address;

        this.city = city;

        this.pin = pin;

        this.state = state;

        this.contactNumber = contactNumber;

        this.secContactNumber = secContactNumber;

        this.yearOfJoining = yearOfJoining;

        this.empId = empId;

    }

}



