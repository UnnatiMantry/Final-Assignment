package com.example.javafinalassignment.service;

import com.example.javafinalassignment.entities.Employee;

public class EmployeeService {
    String getEmployeeCode(Employee emp)
    {
        String empCode="";
//HOP<Year of Joining> FTE <4 digit employee id>

        empCode="HOP"+emp.getYearOfJoining()+""+emp.getEmpType()+""+emp.getEmpId();
        return empCode;
    }

    String getEmailId(Employee emp)
    {
        return emp.getFirstName()+"."+emp.getLastName()+"@hoppipolla.com";
    }

}
